# StoryTellar

## To install

```
pip install storyscience
```

## To build package

```
python3 setup.py sdist bdist_wheel
```

## To upload to PYPI

```
twine upload dist/*
```
