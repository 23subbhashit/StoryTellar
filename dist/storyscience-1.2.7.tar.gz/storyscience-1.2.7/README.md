# StoryTellar

## To install

```
pip install storyscience
```

## To build package

```
python setup.py sdist bdist_wheel
```

## To upload to PYPI

```
twine upload dist/*
```
